import { useState, useEffect, useRef } from 'react'
import { getDietByDate, addDietEntry, deleteDietEntry, getProfile } from '../lib/storage'

const todayStr = () => new Date().toISOString().split('T')[0]
const uid = () => Math.random().toString(36).slice(2)

export default function Diet() {
  const [entries, setEntries] = useState([])
  const [profile, setProfile] = useState(null)
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm] = useState({ meal: '', calories: '', protein: '', photo: null })
  const fileRef = useRef()

  const load = () => { setEntries(getDietByDate(todayStr())); setProfile(getProfile()) }
  useEffect(() => { load() }, [])

  const totalCal = entries.reduce((s, e) => s + (e.calories || 0), 0)
  const totalProt = entries.reduce((s, e) => s + (e.protein || 0), 0)
  const calPct = Math.min(100, profile ? Math.round((totalCal / profile.targetCalories) * 100) : 0)
  const protPct = Math.min(100, profile ? Math.round((totalProt / profile.targetProtein) * 100) : 0)

  const handlePhoto = (e) => {
    const file = e.target.files[0]; if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => setForm(f => ({ ...f, photo: ev.target.result }))
    reader.readAsDataURL(file)
  }

  const handleAdd = () => {
    if (!form.meal || !form.calories) return
    addDietEntry(todayStr(), { id: uid(), meal: form.meal, calories: +form.calories, protein: form.protein ? +form.protein : 0, photo: form.photo, time: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) })
    setForm({ meal: '', calories: '', protein: '', photo: null })
    setShowAdd(false)
    load()
  }

  const INP = { background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', padding:'12px 14px', fontSize:'15px', width:'100%' }

  return (
    <div style={{ paddingBottom: '24px' }}>
      {/* Header */}
      <div style={{ padding:'52px 20px 20px', background:'var(--bg2)', borderBottom:'1px solid var(--border)' }}>
        <h2 style={{ fontSize:'26px', fontWeight:800, marginBottom:'16px' }}>Diet</h2>
        <MacroBar label="CALORIES" current={totalCal} target={profile?.targetCalories} unit="" pct={calPct} color="var(--red)" />
        <div style={{ marginTop:'10px' }}>
          <MacroBar label="PROTEIN" current={`${totalProt}g`} target={`${profile?.targetProtein}g`} unit="" pct={protPct} color="#4a9eb5" />
        </div>
      </div>

      {/* Meal list */}
      <div style={{ padding:'16px 20px', display:'flex', flexDirection:'column', gap:'8px' }}>
        {entries.length === 0 && !showAdd && (
          <div style={{ textAlign:'center', padding:'32px 0', color:'var(--text-muted)', fontSize:'13px' }}>No meals logged today</div>
        )}
        {entries.map(entry => (
          <div key={entry.id} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'12px', overflow:'hidden' }}>
            {entry.photo && <img src={entry.photo} alt="" style={{ width:'100%', height:'130px', objectFit:'cover' }} />}
            <div style={{ padding:'14px' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:'15px' }}>{entry.meal}</div>
                  <div style={{ fontSize:'10px', color:'var(--text-muted)', marginTop:'2px', fontFamily:'var(--mono)' }}>{entry.time}</div>
                </div>
                <button onClick={() => { deleteDietEntry(todayStr(), entry.id); load() }} style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:'18px', padding:'0 0 0 8px' }}>×</button>
              </div>
              <div style={{ display:'flex', gap:'14px', marginTop:'8px' }}>
                <span style={{ fontSize:'13px', color:'var(--red)', fontWeight:700, fontFamily:'var(--mono)' }}>{entry.calories} kcal</span>
                {entry.protein > 0 && <span style={{ fontSize:'13px', color:'#4a9eb5', fontWeight:700, fontFamily:'var(--mono)' }}>{entry.protein}g protein</span>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add form */}
      {showAdd && (
        <div style={{ padding:'0 20px', display:'flex', flexDirection:'column', gap:'10px' }}>
          <div style={{ fontSize:'9px', letterSpacing:'4px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>LOG MEAL</div>
          <input style={INP} placeholder="Meal name *" value={form.meal} onChange={e=>setForm(f=>({...f,meal:e.target.value}))} />
          <div style={{ display:'flex', gap:'10px' }}>
            <input style={INP} type="number" placeholder="Calories *" value={form.calories} onChange={e=>setForm(f=>({...f,calories:e.target.value}))} />
            <input style={INP} type="number" placeholder="Protein (g)" value={form.protein} onChange={e=>setForm(f=>({...f,protein:e.target.value}))} />
          </div>
          <input ref={fileRef} type="file" accept="image/*" capture="environment" onChange={handlePhoto} style={{ display:'none' }} />
          {form.photo ? (
            <div style={{ position:'relative' }}>
              <img src={form.photo} alt="" style={{ width:'100%', height:'130px', objectFit:'cover', borderRadius:'8px' }} />
              <button onClick={()=>setForm(f=>({...f,photo:null}))} style={{ position:'absolute', top:'8px', right:'8px', background:'rgba(0,0,0,0.7)', border:'none', color:'white', borderRadius:'50%', width:'28px', height:'28px', fontSize:'16px' }}>×</button>
            </div>
          ) : (
            <button onClick={()=>fileRef.current.click()} style={{ background:'var(--bg3)', border:'1px dashed var(--border)', borderRadius:'8px', padding:'13px', color:'var(--text-muted)', fontSize:'13px' }}>📷 Add Photo (optional)</button>
          )}
          <div style={{ display:'flex', gap:'10px' }}>
            <button onClick={()=>setShowAdd(false)} style={{ flex:1, background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', padding:'12px', color:'var(--text-dim)', fontWeight:600 }}>Cancel</button>
            <button onClick={handleAdd} style={{ flex:2, background:'var(--red)', border:'none', borderRadius:'8px', padding:'12px', color:'white', fontWeight:700, fontSize:'14px' }}>LOG MEAL</button>
          </div>
        </div>
      )}

      {!showAdd && (
        <div style={{ padding:'8px 20px 0' }}>
          <button onClick={()=>setShowAdd(true)} style={{ width:'100%', background:'var(--red)', border:'none', borderRadius:'12px', padding:'16px', color:'white', fontWeight:700, fontSize:'15px', letterSpacing:'1px' }}>+ LOG MEAL</button>
        </div>
      )}
    </div>
  )
}

function MacroBar({ label, current, target, pct, color }) {
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', marginBottom:'6px' }}>
        <span style={{ fontSize:'9px', letterSpacing:'3px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>{label}</span>
        <span style={{ fontSize:'11px', color, fontFamily:'var(--mono)', fontWeight:700 }}>{current} <span style={{ color:'var(--text-muted)', fontWeight:400 }}>/ {target}</span></span>
      </div>
      <div style={{ height:'4px', background:'var(--border)', borderRadius:'2px' }}>
        <div style={{ height:'100%', width:`${pct}%`, background:color, borderRadius:'2px', transition:'width 0.4s' }} />
      </div>
    </div>
  )
}
