import { useState } from 'react'
import { saveProfile } from '../lib/storage'

export default function Setup({ onComplete }) {
  const [name, setName] = useState('')
  const [goal, setGoal] = useState('bulk')
  const [calories, setCalories] = useState('2800')
  const [protein, setProtein] = useState('180')
  const [weight, setWeight] = useState('')
  const [unit, setUnit] = useState('lbs')

  const handleSubmit = () => {
    if (!name.trim()) return
    const p = { name: name.trim(), goal, targetCalories: +calories, targetProtein: +protein, weight: weight ? +weight : null, unit, createdAt: new Date().toISOString() }
    saveProfile(p)
    onComplete(p)
  }

  const inp = { background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--text)', padding: '12px 14px', fontSize: '15px', width: '100%' }

  return (
    <div style={{ height: '100vh', background: 'var(--bg)', display: 'flex', flexDirection: 'column', justifyContent: 'center', padding: '32px 24px', maxWidth: '430px', margin: '0 auto', overflowY: 'auto' }}>
      <div style={{ marginBottom: '36px' }}>
        <div style={{ fontSize: '10px', letterSpacing: '5px', color: 'var(--red)', marginBottom: '8px', fontFamily: 'var(--mono)' }}>WELCOME TO</div>
        <h1 style={{ fontSize: '52px', fontWeight: 900, letterSpacing: '-2px', color: 'var(--white)', lineHeight: 1 }}>BodMax</h1>
        <p style={{ color: 'var(--text-dim)', marginTop: '10px', fontSize: '14px' }}>Set up your profile to get started.</p>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
        <Field label="YOUR NAME">
          <input style={inp} placeholder="e.g. Alex" value={name} onChange={e => setName(e.target.value)} />
        </Field>

        <Field label="GOAL">
          <div style={{ display: 'flex', gap: '8px' }}>
            {['bulk', 'cut', 'maintain'].map(g => (
              <button key={g} onClick={() => setGoal(g)} style={{ flex: 1, padding: '10px', borderRadius: '8px', border: `1px solid ${goal === g ? 'var(--red)' : 'var(--border)'}`, background: goal === g ? 'var(--red-low)' : 'var(--bg3)', color: goal === g ? 'var(--red)' : 'var(--text-dim)', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '1px' }}>{g}</button>
            ))}
          </div>
        </Field>

        <div style={{ display: 'flex', gap: '12px' }}>
          <Field label="DAILY CALORIES" style={{ flex: 1 }}>
            <input style={inp} type="number" value={calories} onChange={e => setCalories(e.target.value)} />
          </Field>
          <Field label="PROTEIN (g)" style={{ flex: 1 }}>
            <input style={inp} type="number" value={protein} onChange={e => setProtein(e.target.value)} />
          </Field>
        </div>

        <Field label="BODYWEIGHT (optional)">
          <div style={{ display: 'flex', gap: '8px' }}>
            <input style={{ ...inp, flex: 1 }} type="number" placeholder="e.g. 185" value={weight} onChange={e => setWeight(e.target.value)} />
            {['lbs', 'kg'].map(u => (
              <button key={u} onClick={() => setUnit(u)} style={{ padding: '12px 14px', borderRadius: '8px', border: `1px solid ${unit === u ? 'var(--red)' : 'var(--border)'}`, background: unit === u ? 'var(--red-low)' : 'var(--bg3)', color: unit === u ? 'var(--red)' : 'var(--text-dim)', fontWeight: 700, fontSize: '13px' }}>{u}</button>
            ))}
          </div>
        </Field>

        <button onClick={handleSubmit} disabled={!name.trim()} style={{ marginTop: '8px', background: name.trim() ? 'var(--red)' : 'var(--border)', color: 'white', border: 'none', borderRadius: '12px', padding: '16px', fontSize: '15px', fontWeight: 700, letterSpacing: '1px', transition: 'background 0.15s' }}>
          LET'S GO →
        </button>
      </div>
    </div>
  )
}

function Field({ label, children, style }) {
  return (
    <div style={style}>
      <div style={{ fontSize: '9px', letterSpacing: '3px', color: 'var(--text-muted)', fontFamily: 'var(--mono)', marginBottom: '8px' }}>{label}</div>
      {children}
    </div>
  )
}
