import { useState, useEffect, useRef } from 'react'
import { getSessions, addSession, checkAndUpdatePR } from '../lib/storage'
import { MUSCLE_GROUPS, EXERCISES, CARDIO_TYPES } from '../lib/ranks'

const uid = () => Math.random().toString(36).slice(2)

export default function Session() {
  const [active, setActive] = useState(null)
  const [sessions, setSessions] = useState([])
  const [showPicker, setShowPicker] = useState(false)
  const [showCardio, setShowCardio] = useState(false)
  const [pickerGroup, setPickerGroup] = useState(MUSCLE_GROUPS[0])
  const [elapsed, setElapsed] = useState(0)
  const [summary, setSummary] = useState(null)
  const [newPRs, setNewPRs] = useState([])
  const timer = useRef(null)

  useEffect(() => { setSessions(getSessions()) }, [])

  useEffect(() => {
    if (active) { timer.current = setInterval(() => setElapsed(e => e + 1), 1000) }
    else { clearInterval(timer.current); setElapsed(0) }
    return () => clearInterval(timer.current)
  }, [!!active])

  const startSession = () => setActive({ id: uid(), date: new Date().toISOString(), exercises: [], cardio: [] })

  const addExercise = (name, group) => {
    setActive(s => ({ ...s, exercises: [...s.exercises, { id: uid(), name, muscleGroup: group, sets: [{ id: uid(), weight: '', reps: '' }] }] }))
    setShowPicker(false)
  }

  const removeExercise = (id) => setActive(s => ({ ...s, exercises: s.exercises.filter(e => e.id !== id) }))

  const addSet = (exId) => setActive(s => ({
    ...s,
    exercises: s.exercises.map(ex => ex.id === exId ? { ...ex, sets: [...ex.sets, { id: uid(), weight: '', reps: '' }] } : ex)
  }))

  const removeSet = (exId, setId) => setActive(s => ({
    ...s,
    exercises: s.exercises.map(ex => ex.id === exId ? { ...ex, sets: ex.sets.filter(st => st.id !== setId) } : ex)
  }))

  const updateSet = (exId, setId, field, val) => setActive(s => ({
    ...s,
    exercises: s.exercises.map(ex => ex.id === exId ? { ...ex, sets: ex.sets.map(st => st.id === setId ? { ...st, [field]: val } : st) } : ex)
  }))

  const addCardio = (c) => { setActive(s => ({ ...s, cardio: [...s.cardio, { ...c, id: uid() }] })); setShowCardio(false) }

  const finishSession = () => {
    const session = { ...active, completedAt: new Date().toISOString(), duration: elapsed }
    const date = new Date().toISOString()
    const prs = []
    session.exercises.forEach(ex => {
      ex.sets.forEach(set => {
        if (set.weight && set.reps) {
          const isNew = checkAndUpdatePR(ex.name, ex.muscleGroup, +set.weight, +set.reps, date)
          if (isNew && !prs.includes(ex.name)) prs.push(ex.name)
        }
      })
    })
    addSession(session)
    setSessions(getSessions())
    setNewPRs(prs)
    setSummary(session)
    setActive(null)
  }

  const fmtTime = (s) => `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`
  const totalVol = (exs) => (exs||[]).reduce((sum, ex) => sum + (ex.sets||[]).reduce((s2, set) => s2 + ((+set.weight||0)*(+set.reps||0)), 0), 0)

  const INP = { background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: '6px', color: 'var(--text)', padding: '8px 6px', fontSize: '15px', textAlign: 'center', width: '100%', fontFamily: 'var(--mono)' }
  const BTN = (v) => ({ border: 'none', borderRadius: '8px', padding: '10px 16px', fontSize: '13px', fontWeight: 600, background: v==='red'?'var(--red)':v==='ghost'?'transparent':'var(--bg3)', color: v==='red'?'white':v==='ghost'?'var(--text-muted)':'var(--text)', ...(v==='ghost'?{border:'1px solid var(--border)'}:{}) })
  const LABEL = { fontSize: '9px', letterSpacing: '4px', color: 'var(--text-muted)', fontFamily: 'var(--mono)' }

  // Summary screen
  if (summary) {
    return (
      <div style={{ padding: '60px 20px', textAlign: 'center' }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>🏁</div>
        <h2 style={{ fontSize: '28px', fontWeight: 800, marginBottom: '4px' }}>Session Done</h2>
        <div style={{ color: 'var(--text-dim)', marginBottom: '28px' }}>{fmtTime(summary.duration||0)} · {(summary.exercises||[]).length} exercises</div>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '24px' }}>
          {[['VOLUME', `${Math.round(totalVol(summary.exercises)).toLocaleString()} lbs`],['SETS',(summary.exercises||[]).reduce((s,e)=>s+e.sets.length,0)]].map(([l,v])=>(
            <div key={l} style={{ flex:1, background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'10px', padding:'14px' }}>
              <div style={{...LABEL,marginBottom:'4px'}}>{l}</div>
              <div style={{ fontSize:'20px', fontWeight:700, fontFamily:'var(--mono)' }}>{v}</div>
            </div>
          ))}
        </div>
        {newPRs.length > 0 && (
          <div style={{ background:'rgba(224,22,30,0.08)', border:'1px solid rgba(224,22,30,0.2)', borderRadius:'12px', padding:'16px', marginBottom:'24px' }}>
            <div style={{ fontSize:'10px', letterSpacing:'3px', color:'var(--red)', marginBottom:'8px', fontFamily:'var(--mono)' }}>🔥 NEW PRs</div>
            {newPRs.map(pr => <div key={pr} style={{ fontWeight:600, marginBottom:'4px' }}>{pr}</div>)}
          </div>
        )}
        <button onClick={() => { setSummary(null); setNewPRs([]) }} style={{ ...BTN('red'), width:'100%', padding:'14px', fontSize:'15px' }}>DONE</button>
      </div>
    )
  }

  // Active session
  if (active) {
    return (
      <div style={{ paddingBottom: '24px' }}>
        <div style={{ padding:'52px 20px 16px', background:'var(--bg2)', borderBottom:'1px solid var(--border)', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
          <div>
            <div style={LABEL}>SESSION IN PROGRESS</div>
            <div style={{ fontSize:'24px', fontWeight:700, color:'var(--red)', fontFamily:'var(--mono)', marginTop:'2px' }}>{fmtTime(elapsed)}</div>
          </div>
          <button onClick={finishSession} style={{ ...BTN('red'), padding:'10px 22px' }}>FINISH</button>
        </div>

        <div style={{ padding:'16px 20px', display:'flex', flexDirection:'column', gap:'12px' }}>
          {active.exercises.map(ex => (
            <div key={ex.id} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'12px', padding:'16px' }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'12px' }}>
                <div>
                  <div style={{ fontWeight:700, fontSize:'15px' }}>{ex.name}</div>
                  <div style={{ fontSize:'9px', color:'var(--red)', letterSpacing:'2px', fontFamily:'var(--mono)', marginTop:'2px' }}>{ex.muscleGroup}</div>
                </div>
                <button onClick={() => removeExercise(ex.id)} style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:'20px' }}>×</button>
              </div>
              <div style={{ display:'grid', gridTemplateColumns:'20px 1fr 1fr 28px', gap:'6px', marginBottom:'6px' }}>
                <span style={{...LABEL}}>#</span>
                <span style={{...LABEL,textAlign:'center'}}>LBS</span>
                <span style={{...LABEL,textAlign:'center'}}>REPS</span>
                <span/>
              </div>
              {ex.sets.map((set, i) => (
                <div key={set.id} style={{ display:'grid', gridTemplateColumns:'20px 1fr 1fr 28px', gap:'6px', marginBottom:'6px', alignItems:'center' }}>
                  <span style={{ fontSize:'11px', color:'var(--text-muted)', fontFamily:'var(--mono)', textAlign:'center' }}>{i+1}</span>
                  <input style={INP} type="number" inputMode="decimal" placeholder="0" value={set.weight} onChange={e=>updateSet(ex.id,set.id,'weight',e.target.value)} />
                  <input style={INP} type="number" inputMode="numeric" placeholder="0" value={set.reps} onChange={e=>updateSet(ex.id,set.id,'reps',e.target.value)} />
                  <button onClick={()=>removeSet(ex.id,set.id)} style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:'18px' }}>−</button>
                </div>
              ))}
              <button onClick={()=>addSet(ex.id)} style={{ ...BTN('ghost'), width:'100%', marginTop:'6px', fontSize:'12px' }}>+ ADD SET</button>
            </div>
          ))}

          {active.cardio.map(c => (
            <div key={c.id} style={{ background:'var(--bg2)', border:'1px solid #1a3a4a', borderRadius:'12px', padding:'14px' }}>
              <div style={{ fontSize:'9px', color:'#4a9eb5', letterSpacing:'2px', fontFamily:'var(--mono)', marginBottom:'4px' }}>CARDIO</div>
              <div style={{ fontWeight:600 }}>{c.type}</div>
              <div style={{ fontSize:'12px', color:'var(--text-dim)', marginTop:'2px' }}>{c.duration} min{c.distance?` · ${c.distance} mi`:''}{c.calories?` · ${c.calories} kcal`:''}</div>
            </div>
          ))}

          <button onClick={()=>setShowPicker(true)} style={{ ...BTN('ghost'), width:'100%', padding:'14px', borderStyle:'dashed' }}>+ ADD EXERCISE</button>
          <button onClick={()=>setShowCardio(true)} style={{ ...BTN('ghost'), width:'100%', padding:'12px', fontSize:'12px' }}>+ ADD CARDIO</button>
        </div>

        {showPicker && <ExercisePicker group={pickerGroup} onGroupChange={setPickerGroup} onSelect={addExercise} onClose={()=>setShowPicker(false)} />}
        {showCardio && <CardioModal onAdd={addCardio} onClose={()=>setShowCardio(false)} />}
      </div>
    )
  }

  // No active session
  return (
    <div style={{ padding:'52px 20px 24px' }}>
      <h2 style={{ fontSize:'26px', fontWeight:800, marginBottom:'4px' }}>Sessions</h2>
      <p style={{ color:'var(--text-dim)', marginBottom:'24px', fontSize:'14px' }}>Log your workout, track your gains</p>
      <button onClick={startSession} style={{ background:'var(--red)', color:'white', border:'none', borderRadius:'12px', padding:'16px', fontSize:'15px', fontWeight:700, letterSpacing:'1px', width:'100%', marginBottom:'32px' }}>
        START SESSION
      </button>
      {sessions.length > 0 && (
        <>
          <div style={{ fontSize:'9px', letterSpacing:'4px', color:'var(--text-muted)', fontFamily:'var(--mono)', marginBottom:'10px' }}>HISTORY</div>
          <div style={{ display:'flex', flexDirection:'column', gap:'8px' }}>
            {sessions.map(s => {
              const vol = (s.exercises||[]).reduce((sum,ex)=>sum+(ex.sets||[]).reduce((s2,set)=>s2+((+set.weight||0)*(+set.reps||0)),0),0)
              const groups = [...new Set((s.exercises||[]).map(e=>e.muscleGroup))].filter(Boolean)
              return (
                <div key={s.id} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'12px', padding:'16px' }}>
                  <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                    <div>
                      <div style={{ fontWeight:700, fontSize:'14px', marginBottom:'3px' }}>{groups.join(', ')||'Workout'}</div>
                      <div style={{ fontSize:'11px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>
                        {(s.exercises||[]).length} exercises · {Math.round(vol).toLocaleString()} lbs{s.duration?` · ${Math.floor(s.duration/60)}m`:''}
                      </div>
                    </div>
                    <span style={{ fontSize:'11px', color:'var(--text-dim)', whiteSpace:'nowrap', marginLeft:'8px' }}>
                      {new Date(s.date).toLocaleDateString('en-US',{month:'short',day:'numeric'})}
                    </span>
                  </div>
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )
}

function ExercisePicker({ group, onGroupChange, onSelect, onClose }) {
  return (
    <Modal onClose={onClose} title="ADD EXERCISE">
      <div style={{ display:'flex', gap:'6px', flexWrap:'wrap', marginBottom:'16px' }}>
        {MUSCLE_GROUPS.map(g => (
          <button key={g} onClick={()=>onGroupChange(g)} style={{ padding:'6px 12px', borderRadius:'20px', border:'none', background:group===g?'var(--red)':'var(--bg3)', color:group===g?'white':'var(--text-dim)', fontSize:'12px', fontWeight:600 }}>{g}</button>
        ))}
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
        {(EXERCISES[group]||[]).map(ex => (
          <button key={ex} onClick={()=>onSelect(ex,group)} style={{ background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', padding:'13px 14px', textAlign:'left', color:'var(--text)', fontSize:'14px' }}>{ex}</button>
        ))}
      </div>
    </Modal>
  )
}

function CardioModal({ onAdd, onClose }) {
  const [type, setType] = useState(CARDIO_TYPES[0])
  const [duration, setDuration] = useState('')
  const [distance, setDistance] = useState('')
  const [calories, setCalories] = useState('')
  const INP = { background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', padding:'11px 12px', fontSize:'15px', width:'100%' }
  return (
    <Modal onClose={onClose} title="ADD CARDIO">
      <div style={{ display:'flex', gap:'6px', flexWrap:'wrap', marginBottom:'16px' }}>
        {CARDIO_TYPES.map(t => (
          <button key={t} onClick={()=>setType(t)} style={{ padding:'6px 12px', borderRadius:'20px', border:'none', background:type===t?'#4a9eb5':'var(--bg3)', color:type===t?'white':'var(--text-dim)', fontSize:'12px', fontWeight:600 }}>{t}</button>
        ))}
      </div>
      <div style={{ display:'flex', flexDirection:'column', gap:'10px', marginBottom:'16px' }}>
        <input style={INP} type="number" placeholder="Duration (minutes) *" value={duration} onChange={e=>setDuration(e.target.value)} />
        <input style={INP} type="number" placeholder="Distance (miles) — optional" value={distance} onChange={e=>setDistance(e.target.value)} />
        <input style={INP} type="number" placeholder="Calories burned — optional" value={calories} onChange={e=>setCalories(e.target.value)} />
      </div>
      <button onClick={()=>duration&&onAdd({type,duration:+duration,distance:distance?+distance:null,calories:calories?+calories:null})}
        style={{ background:'#4a9eb5', border:'none', borderRadius:'8px', padding:'14px', width:'100%', color:'white', fontWeight:700, fontSize:'14px' }}>
        ADD CARDIO
      </button>
    </Modal>
  )
}

function Modal({ children, onClose, title }) {
  return (
    <div style={{ position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', zIndex:100, display:'flex', alignItems:'flex-end' }} onClick={onClose}>
      <div style={{ background:'var(--bg2)', borderRadius:'20px 20px 0 0', padding:'24px 20px 40px', width:'100%', maxHeight:'80vh', overflowY:'auto' }} onClick={e=>e.stopPropagation()}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'20px' }}>
          <span style={{ fontSize:'9px', letterSpacing:'4px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>{title}</span>
          <button onClick={onClose} style={{ background:'none', border:'none', color:'var(--text-dim)', fontSize:'22px' }}>×</button>
        </div>
        {children}
      </div>
    </div>
  )
}
