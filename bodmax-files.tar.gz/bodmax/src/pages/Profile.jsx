import { useState, useEffect } from 'react'
import { getProfile, saveProfile, getSessions, getPRs } from '../lib/storage'
import { calcVolumes } from '../lib/ranks'

export default function Profile({ onProfileUpdate }) {
  const [profile, setProfile] = useState(null)
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState({})
  const [stats, setStats] = useState({ sessions: 0, prs: 0, totalVol: 0 })
  const [showReset, setShowReset] = useState(false)

  useEffect(() => {
    const p = getProfile()
    setProfile(p); setForm(p||{})
    const sessions = getSessions()
    const vols = calcVolumes(sessions)
    setStats({ sessions: sessions.length, prs: getPRs().length, totalVol: Object.values(vols).reduce((s,v)=>s+v,0) })
  }, [])

  const save = () => { saveProfile(form); setProfile(form); onProfileUpdate(form); setEditing(false) }
  const resetAll = () => { ['bm_sessions','bm_diet','bm_weight','bm_prs','bm_profile'].forEach(k=>localStorage.removeItem(k)); window.location.reload() }

  const INP = { background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', padding:'12px 14px', fontSize:'15px', width:'100%' }
  const LABEL = (s) => <div style={{ fontSize:'9px', letterSpacing:'3px', color:'var(--text-muted)', fontFamily:'var(--mono)', marginBottom:'8px' }}>{s}</div>

  if (!profile) return null

  return (
    <div style={{ padding:'52px 20px 40px', overflowY:'auto' }}>
      {/* Avatar */}
      <div style={{ display:'flex', alignItems:'center', gap:'16px', marginBottom:'28px' }}>
        <div style={{ width:'64px', height:'64px', borderRadius:'50%', background:'rgba(224,22,30,0.12)', border:'2px solid var(--red)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'26px', fontWeight:800, color:'var(--red)', flexShrink:0 }}>
          {profile.name?.[0]?.toUpperCase()}
        </div>
        <div>
          <h2 style={{ fontSize:'22px', fontWeight:800, marginBottom:'6px' }}>{profile.name}</h2>
          <span style={{ fontSize:'10px', letterSpacing:'2px', fontFamily:'var(--mono)', fontWeight:700, padding:'3px 10px', borderRadius:'4px', ...(profile.goal==='bulk'?{color:'var(--red)',background:'rgba(224,22,30,0.1)'}:profile.goal==='cut'?{color:'#4a9eb5',background:'rgba(74,158,181,0.1)'}:{color:'#6a9a6a',background:'rgba(106,154,106,0.1)'}) }}>
            {profile.goal?.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Stats */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'8px', marginBottom:'28px' }}>
        {[['SESSIONS',stats.sessions],['PRs SET',stats.prs],['VOLUME',`${Math.round(stats.totalVol/1000)}k`]].map(([l,v])=>(
          <div key={l} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'10px', padding:'14px', textAlign:'center' }}>
            <div style={{ fontSize:'22px', fontWeight:800, color:'var(--red)', fontFamily:'var(--mono)' }}>{v}</div>
            <div style={{ fontSize:'8px', letterSpacing:'2px', color:'var(--text-muted)', fontFamily:'var(--mono)', marginTop:'3px' }}>{l}</div>
          </div>
        ))}
      </div>

      {/* Edit form or info */}
      {editing ? (
        <div style={{ display:'flex', flexDirection:'column', gap:'14px', marginBottom:'24px' }}>
          <div>{LABEL('NAME')}<input style={INP} value={form.name||''} onChange={e=>setForm(f=>({...f,name:e.target.value}))} /></div>

          <div>
            {LABEL('GOAL')}
            <div style={{ display:'flex', gap:'8px' }}>
              {['bulk','cut','maintain'].map(g=>(
                <button key={g} onClick={()=>setForm(f=>({...f,goal:g}))} style={{ flex:1, padding:'10px', borderRadius:'8px', border:`1px solid ${form.goal===g?'var(--red)':'var(--border)'}`, background:form.goal===g?'rgba(224,22,30,0.1)':'var(--bg3)', color:form.goal===g?'var(--red)':'var(--text-dim)', fontSize:'12px', fontWeight:700, textTransform:'uppercase', letterSpacing:'1px' }}>{g}</button>
              ))}
            </div>
          </div>

          <div style={{ display:'flex', gap:'12px' }}>
            <div style={{ flex:1 }}>{LABEL('CALORIES')}<input style={INP} type="number" value={form.targetCalories||''} onChange={e=>setForm(f=>({...f,targetCalories:+e.target.value}))} /></div>
            <div style={{ flex:1 }}>{LABEL('PROTEIN (g)')}<input style={INP} type="number" value={form.targetProtein||''} onChange={e=>setForm(f=>({...f,targetProtein:+e.target.value}))} /></div>
          </div>

          <div style={{ display:'flex', gap:'10px', marginTop:'4px' }}>
            <button onClick={()=>setEditing(false)} style={{ flex:1, background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', padding:'12px', color:'var(--text-dim)', fontWeight:600 }}>Cancel</button>
            <button onClick={save} style={{ flex:2, background:'var(--red)', border:'none', borderRadius:'8px', padding:'12px', color:'white', fontWeight:700, fontSize:'14px' }}>SAVE</button>
          </div>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:'6px', marginBottom:'24px' }}>
          {[['DAILY CALORIES',`${profile.targetCalories} kcal`],['PROTEIN TARGET',`${profile.targetProtein}g`],['WEIGHT UNIT',profile.unit],['MEMBER SINCE',new Date(profile.createdAt).toLocaleDateString('en-US',{month:'long',year:'numeric'})]].map(([l,v])=>(
            <div key={l} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'8px', padding:'12px 14px' }}>
              <span style={{ fontSize:'9px', letterSpacing:'2px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>{l}</span>
              <span style={{ fontSize:'14px', fontWeight:600 }}>{v}</span>
            </div>
          ))}
          <button onClick={()=>setEditing(true)} style={{ marginTop:'8px', background:'none', border:'1px solid var(--border)', borderRadius:'10px', padding:'14px', color:'var(--text)', fontWeight:600, fontSize:'14px', width:'100%' }}>EDIT PROFILE</button>
        </div>
      )}

      {/* Danger zone */}
      {!showReset ? (
        <button onClick={()=>setShowReset(true)} style={{ background:'none', border:'none', color:'var(--text-muted)', fontSize:'12px', width:'100%', padding:'8px' }}>Reset all data</button>
      ) : (
        <div style={{ background:'rgba(224,22,30,0.05)', border:'1px solid rgba(224,22,30,0.2)', borderRadius:'10px', padding:'16px' }}>
          <div style={{ fontSize:'13px', color:'var(--red)', fontWeight:600, marginBottom:'12px' }}>⚠ This will permanently delete all your data</div>
          <div style={{ display:'flex', gap:'8px' }}>
            <button onClick={()=>setShowReset(false)} style={{ flex:1, background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', padding:'10px', color:'var(--text-dim)', fontWeight:600 }}>Cancel</button>
            <button onClick={resetAll} style={{ flex:1, background:'var(--red)', border:'none', borderRadius:'8px', padding:'10px', color:'white', fontWeight:700 }}>DELETE ALL</button>
          </div>
        </div>
      )}
    </div>
  )
}
