import { useState, useEffect } from 'react'
import { getProfile, getSessions, getDietByDate } from '../lib/storage'
import { calcVolumes, getRank, getRankProgress, MUSCLE_GROUPS } from '../lib/ranks'

const todayStr = () => new Date().toISOString().split('T')[0]
const fmt = (n) => Math.round(n || 0).toLocaleString()

export default function Dashboard() {
  const [profile, setProfile] = useState(null)
  const [volumes, setVolumes] = useState({})
  const [todayDiet, setTodayDiet] = useState([])
  const [recentSessions, setRecentSessions] = useState([])

  useEffect(() => {
    const p = getProfile()
    const sessions = getSessions()
    setProfile(p)
    setVolumes(calcVolumes(sessions))
    setTodayDiet(getDietByDate(todayStr()))
    setRecentSessions(sessions.slice(0, 3))
  }, [])

  const totalCal = todayDiet.reduce((s, e) => s + (e.calories || 0), 0)
  const totalProt = todayDiet.reduce((s, e) => s + (e.protein || 0), 0)
  const calPct = Math.min(100, profile ? Math.round((totalCal / profile.targetCalories) * 100) : 0)
  const protPct = Math.min(100, profile ? Math.round((totalProt / profile.targetProtein) * 100) : 0)

  const greeting = () => {
    const h = new Date().getHours()
    if (h < 12) return 'Good morning'
    if (h < 17) return 'Good afternoon'
    return 'Good evening'
  }

  return (
    <div style={{ paddingBottom: '24px' }}>
      {/* Header */}
      <div style={{ padding: '52px 20px 20px', background: 'var(--bg2)', borderBottom: '1px solid var(--border)' }}>
        <div style={{ fontSize: '10px', color: 'var(--text-muted)', letterSpacing: '3px', fontFamily: 'var(--mono)', marginBottom: '4px' }}>
          {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' }).toUpperCase()}
        </div>
        <h1 style={{ fontSize: '26px', fontWeight: 700 }}>
          {greeting()}, <span style={{ color: 'var(--red)' }}>{profile?.name?.split(' ')[0] || 'Athlete'}</span>
        </h1>
      </div>

      {/* Nutrition */}
      <div style={{ padding: '20px 20px 0' }}>
        <Label>TODAY'S NUTRITION</Label>
        <div style={{ display: 'flex', gap: '10px', marginTop: '10px' }}>
          <MacroCard label="CALORIES" value={fmt(totalCal)} target={fmt(profile?.targetCalories)} pct={calPct} color="var(--red)" />
          <MacroCard label="PROTEIN" value={`${fmt(totalProt)}g`} target={`${fmt(profile?.targetProtein)}g`} pct={protPct} color="#4a9eb5" />
        </div>
      </div>

      {/* Muscle Rankings */}
      <div style={{ padding: '20px 20px 0' }}>
        <Label>MUSCLE RANKINGS</Label>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', marginTop: '10px' }}>
          {MUSCLE_GROUPS.map(group => {
            const vol = volumes[group] || 0
            const rank = getRank(vol)
            const progress = getRankProgress(vol)
            return (
              <div key={group} style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '12px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                  <span style={{ fontSize: '13px', fontWeight: 600 }}>{group}</span>
                  <span style={{ fontSize: '8px', letterSpacing: '1.5px', fontFamily: 'var(--mono)', color: rank.color, fontWeight: 700 }}>{rank.name}</span>
                </div>
                <div style={{ height: '3px', background: 'var(--border)', borderRadius: '2px' }}>
                  <div style={{ height: '100%', width: `${progress}%`, background: rank.color, borderRadius: '2px' }} />
                </div>
                <div style={{ fontSize: '9px', color: 'var(--text-muted)', marginTop: '4px', fontFamily: 'var(--mono)' }}>{fmt(vol)} lbs</div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Recent Sessions */}
      <div style={{ padding: '20px 20px 0' }}>
        <Label>RECENT SESSIONS</Label>
        {recentSessions.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '32px 0', color: 'var(--text-muted)', fontSize: '13px' }}>No sessions yet — hit the Session tab to start 💪</div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', marginTop: '10px' }}>
            {recentSessions.map(s => {
              const vol = (s.exercises || []).reduce((sum, ex) => sum + (ex.sets || []).reduce((s2, set) => s2 + ((+set.weight||0)*(+set.reps||0)), 0), 0)
              const groups = [...new Set((s.exercises || []).map(e => e.muscleGroup))].filter(Boolean)
              return (
                <div key={s.id} style={{ background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '14px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ fontWeight: 700, fontSize: '14px' }}>{groups.join(', ') || 'Workout'}</span>
                    <span style={{ fontSize: '11px', color: 'var(--text-dim)' }}>{new Date(s.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</span>
                  </div>
                  <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '3px', fontFamily: 'var(--mono)' }}>
                    {(s.exercises || []).length} exercises · {fmt(vol)} lbs
                    {s.duration ? ` · ${Math.floor(s.duration/60)}m` : ''}
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

function Label({ children }) {
  return <div style={{ fontSize: '9px', letterSpacing: '4px', color: 'var(--text-muted)', fontFamily: 'var(--mono)' }}>{children}</div>
}

function MacroCard({ label, value, target, pct, color }) {
  return (
    <div style={{ flex: 1, background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: '10px', padding: '14px' }}>
      <div style={{ fontSize: '9px', letterSpacing: '3px', color: 'var(--text-muted)', fontFamily: 'var(--mono)', marginBottom: '5px' }}>{label}</div>
      <div style={{ fontSize: '22px', fontWeight: 700, color, fontFamily: 'var(--mono)' }}>{value}</div>
      <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginBottom: '8px' }}>/ {target}</div>
      <div style={{ height: '3px', background: 'var(--border)', borderRadius: '2px' }}>
        <div style={{ height: '100%', width: `${pct}%`, background: color, borderRadius: '2px' }} />
      </div>
    </div>
  )
}
