import { useState, useEffect } from 'react'
import { getWeightLog, addWeight, getPRs, getSessions, getProfile } from '../lib/storage'
import { calcVolumes, getRank, MUSCLE_GROUPS } from '../lib/ranks'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

const uid = () => Math.random().toString(36).slice(2)

const CHART_TOOLTIP = { contentStyle: { background: '#141414', border: '1px solid #1c1c1c', borderRadius: '8px', color: '#f4f4f4', fontSize: '12px' }, cursor: { stroke: '#333' } }

export default function Progress() {
  const [tab, setTab] = useState('weight')
  const [weightLog, setWeightLog] = useState([])
  const [prs, setPRs] = useState([])
  const [volumes, setVolumes] = useState({})
  const [profile, setProfile] = useState(null)
  const [showAddWeight, setShowAddWeight] = useState(false)
  const [newWeight, setNewWeight] = useState('')

  useEffect(() => {
    setWeightLog(getWeightLog())
    setPRs(getPRs())
    setVolumes(calcVolumes(getSessions()))
    setProfile(getProfile())
  }, [])

  const handleAddWeight = () => {
    if (!newWeight) return
    addWeight({ id: uid(), date: new Date().toISOString().split('T')[0], weight: +newWeight })
    setWeightLog(getWeightLog())
    setNewWeight('')
    setShowAddWeight(false)
  }

  const weightChartData = weightLog.slice(-30).map(e => ({
    date: new Date(e.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
    weight: e.weight,
  }))

  const volumeData = MUSCLE_GROUPS.map(g => ({
    name: g.slice(0, 4).toUpperCase(),
    vol: Math.round((volumes[g] || 0) / 1000 * 10) / 10,
  }))

  const INP = { background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', color:'var(--text)', padding:'12px 14px', fontSize:'15px', outline:'none' }

  return (
    <div style={{ paddingBottom: '24px' }}>
      <div style={{ padding:'52px 20px 0', borderBottom:'1px solid var(--border)' }}>
        <h2 style={{ fontSize:'26px', fontWeight:800, marginBottom:'16px' }}>Progress</h2>
        <div style={{ display:'flex' }}>
          {['weight','prs','volume'].map(t => (
            <button key={t} onClick={()=>setTab(t)} style={{ flex:1, background:'none', border:'none', borderBottom:`2px solid ${tab===t?'var(--red)':'transparent'}`, color:tab===t?'var(--red)':'var(--text-muted)', padding:'10px 0', fontSize:'9px', letterSpacing:'3px', fontFamily:'var(--mono)', fontWeight:600, textTransform:'uppercase' }}>{t}</button>
          ))}
        </div>
      </div>

      <div style={{ padding:'20px' }}>

        {/* WEIGHT TAB */}
        {tab === 'weight' && (
          <div>
            {weightChartData.length > 1 && (
              <div style={{ marginBottom:'24px', background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'12px', padding:'16px' }}>
                <div style={{ fontSize:'9px', letterSpacing:'4px', color:'var(--text-muted)', fontFamily:'var(--mono)', marginBottom:'12px' }}>LAST 30 ENTRIES</div>
                <ResponsiveContainer width="100%" height={180}>
                  <LineChart data={weightChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" />
                    <XAxis dataKey="date" tick={{ fill:'#444', fontSize:9 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                    <YAxis tick={{ fill:'#444', fontSize:9 }} axisLine={false} tickLine={false} domain={['dataMin - 3','dataMax + 3']} />
                    <Tooltip {...CHART_TOOLTIP} />
                    <Line type="monotone" dataKey="weight" stroke="#e0161e" strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            {!showAddWeight ? (
              <button onClick={()=>setShowAddWeight(true)} style={{ width:'100%', background:'var(--red)', border:'none', borderRadius:'12px', padding:'14px', color:'white', fontWeight:700, fontSize:'14px', marginBottom:'16px' }}>+ LOG WEIGHT</button>
            ) : (
              <div style={{ display:'flex', gap:'10px', marginBottom:'16px' }}>
                <input style={{ ...INP, flex:1 }} type="number" inputMode="decimal" placeholder={`Weight (${profile?.unit||'lbs'})`} value={newWeight} onChange={e=>setNewWeight(e.target.value)} autoFocus />
                <button onClick={handleAddWeight} style={{ background:'var(--red)', border:'none', borderRadius:'8px', padding:'12px 18px', color:'white', fontWeight:700 }}>LOG</button>
                <button onClick={()=>setShowAddWeight(false)} style={{ background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'8px', padding:'12px 14px', color:'var(--text-dim)' }}>×</button>
              </div>
            )}

            {weightLog.length === 0 && <div style={{ textAlign:'center', padding:'32px 0', color:'var(--text-muted)', fontSize:'13px' }}>No weight logged yet</div>}

            <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
              {[...weightLog].reverse().slice(0, 15).map(e => (
                <div key={e.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'8px', padding:'12px 14px' }}>
                  <span style={{ fontSize:'13px', color:'var(--text-dim)' }}>{new Date(e.date).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}</span>
                  <span style={{ fontSize:'20px', fontWeight:700, color:'var(--red)', fontFamily:'var(--mono)' }}>{e.weight} <span style={{ fontSize:'11px', fontWeight:400, color:'var(--text-muted)' }}>{profile?.unit||'lbs'}</span></span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* PRs TAB */}
        {tab === 'prs' && (
          <div>
            {prs.length === 0 && <div style={{ textAlign:'center', padding:'40px 0', color:'var(--text-muted)', fontSize:'13px' }}>No PRs yet. Log a session to set your first.</div>}
            {MUSCLE_GROUPS.map(group => {
              const groupPRs = prs.filter(p => p.muscleGroup === group)
              if (!groupPRs.length) return null
              return (
                <div key={group} style={{ marginBottom:'24px' }}>
                  <div style={{ fontSize:'9px', letterSpacing:'4px', color:'var(--red)', fontFamily:'var(--mono)', marginBottom:'8px' }}>{group.toUpperCase()}</div>
                  <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
                    {groupPRs.map(pr => (
                      <div key={pr.exercise} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'10px', padding:'14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                        <div>
                          <div style={{ fontWeight:600, fontSize:'14px' }}>{pr.exercise}</div>
                          <div style={{ fontSize:'10px', color:'var(--text-muted)', marginTop:'2px', fontFamily:'var(--mono)' }}>{new Date(pr.date).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'2-digit' })}</div>
                        </div>
                        <div style={{ textAlign:'right' }}>
                          <div style={{ fontSize:'22px', fontWeight:800, color:'var(--red)', fontFamily:'var(--mono)' }}>{pr.weight}</div>
                          <div style={{ fontSize:'10px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>{pr.reps} reps · lbs</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* VOLUME TAB */}
        {tab === 'volume' && (
          <div>
            <div style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'12px', padding:'16px', marginBottom:'20px' }}>
              <div style={{ fontSize:'9px', letterSpacing:'4px', color:'var(--text-muted)', fontFamily:'var(--mono)', marginBottom:'12px' }}>VOLUME BY MUSCLE (k lbs)</div>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={volumeData} barCategoryGap="30%">
                  <CartesianGrid strokeDasharray="3 3" stroke="#1a1a1a" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill:'#444', fontSize:9 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill:'#444', fontSize:9 }} axisLine={false} tickLine={false} unit="k" />
                  <Tooltip {...CHART_TOOLTIP} formatter={(v) => [`${v}k lbs`, 'Volume']} />
                  <Bar dataKey="vol" fill="#e0161e" radius={[4,4,0,0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
              {MUSCLE_GROUPS.map(g => {
                const vol = volumes[g]||0
                const rank = getRank(vol)
                return (
                  <div key={g} style={{ background:'var(--bg2)', border:'1px solid var(--border)', borderRadius:'10px', padding:'12px 14px', display:'flex', justifyContent:'space-between', alignItems:'center' }}>
                    <span style={{ fontWeight:600, fontSize:'14px' }}>{g}</span>
                    <div style={{ textAlign:'right' }}>
                      <div style={{ fontSize:'9px', letterSpacing:'2px', color:rank.color, fontFamily:'var(--mono)', fontWeight:700 }}>{rank.name}</div>
                      <div style={{ fontSize:'10px', color:'var(--text-muted)', fontFamily:'var(--mono)' }}>{Math.round(vol).toLocaleString()} lbs</div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
