import { useLocation, useNavigate } from 'react-router-dom'

const tabs = [
  { path: '/', label: 'HOME',    icon: '⊞' },
  { path: '/session', label: 'SESSION', icon: '◈' },
  { path: '/diet',    label: 'DIET',    icon: '◉' },
  { path: '/progress',label: 'PROGRESS',icon: '▲' },
  { path: '/profile', label: 'PROFILE', icon: '○' },
]

export default function BottomNav() {
  const loc = useLocation()
  const nav = useNavigate()
  return (
    <div style={{
      background: 'var(--bg2)', borderTop: '1px solid var(--border)',
      display: 'flex', flexShrink: 0,
      paddingBottom: 'env(safe-area-inset-bottom)',
    }}>
      {tabs.map(tab => {
        const active = loc.pathname === tab.path
        return (
          <button key={tab.path} onClick={() => nav(tab.path)} style={{
            flex: 1, background: 'none', border: 'none',
            padding: '10px 0 8px', display: 'flex', flexDirection: 'column',
            alignItems: 'center', gap: '3px',
            color: active ? 'var(--red)' : 'var(--text-muted)',
            transition: 'color 0.15s',
          }}>
            <span style={{ fontSize: '17px', lineHeight: 1 }}>{tab.icon}</span>
            <span style={{ fontSize: '8px', letterSpacing: '1px', fontFamily: 'var(--mono)' }}>{tab.label}</span>
          </button>
        )
      })}
    </div>
  )
}
