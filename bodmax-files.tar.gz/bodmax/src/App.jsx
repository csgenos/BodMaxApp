import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import BottomNav from './components/BottomNav'
import Setup from './pages/Setup'
import Dashboard from './pages/Dashboard'
import Session from './pages/Session'
import Diet from './pages/Diet'
import Progress from './pages/Progress'
import Profile from './pages/Profile'
import { getProfile } from './lib/storage'

export default function App() {
  const [profile, setProfile] = useState(undefined)

  useEffect(() => { setProfile(getProfile()) }, [])

  if (profile === undefined) return null
  if (!profile) return <Setup onComplete={(p) => setProfile(p)} />

  return (
    <BrowserRouter>
      <div style={{
        maxWidth: '430px', margin: '0 auto', height: '100vh',
        display: 'flex', flexDirection: 'column', background: 'var(--bg)',
      }}>
        <div style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', WebkitOverflowScrolling: 'touch' }}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/session" element={<Session />} />
            <Route path="/diet" element={<Diet />} />
            <Route path="/progress" element={<Progress />} />
            <Route path="/profile" element={<Profile onProfileUpdate={setProfile} />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </div>
        <BottomNav />
      </div>
    </BrowserRouter>
  )
}
